package com.cg.test;

import com.cg.beans.*;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class DateMethodsTest {

	@BeforeClass
	public static void setUpTestEnv() {		}

	@Before
	public void setUpTestData() {		}


	
	@Test
	public void testGetDay()	{
		Date d1= new Date(10, 04, 1997	);
		assertEquals(10, d1.getDay());
	}

	@Test
	public void testGetMonth()	{
		Date d1= new Date(12, 04, 1997);
		assertEquals(04, d1.getMonth());
	}

	@Test
	public void testGetYear()	{
		Date d1= new Date(12, 04, 1997);
		assertEquals(1997, d1.getYear());
	}
	@Test
	public void testSetDay()	{
		Date d1= new Date(10, 04, 1997);
		d1.setDay(12);
		assertEquals(12, d1.getDay());
	}

	@Test
	public void testSetMonth()	{
		Date d1= new Date(12, 05, 1997);
		d1.setMonth(04);
		assertEquals(04, d1.getMonth());
	}

	@Test
	public void testSetYear()	{
		Date d1= new Date(12, 04, 1999);
		d1.setYear(1997);
		assertEquals(1997, d1.getYear());
	}

	@After
	public void tearDownTestData()	{	}

	@AfterClass
	public static void tearDownTestEnv()	{	}





}

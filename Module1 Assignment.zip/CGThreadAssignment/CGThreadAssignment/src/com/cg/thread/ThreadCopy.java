package com.cg.thread;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

public class ThreadCopy extends Thread {
	
	public static void main(String []args)throws InterruptedException, IOException,InterruptedException
	{
				
		 ThreadCopy thr1 = new ThreadCopy();
		 thr1.sleep(100);
		 thr1.start();
		
		
	}
	public void run()
	 {
        FileInputStream instream = null;
    	FileOutputStream outstream = null;
     
        	try{
        	    File infile =new File("D:\\\\src.txt");
        	    File outfile =new File("D:\\\\dest.txt");
     
        	    instream = new FileInputStream(infile);
        	    outstream = new FileOutputStream(outfile);
     
        	    byte[] buffer = new byte[1024];
     
        	    int length;
        	    /*copying the contents from input stream to
        	     * output stream using read and write methods
        	     */
        	 
        	    while ((length = instream.read(buffer)) > 0){
        	    	if(length%10==0)
        	    	{
        	    	
        	    		buffer.wait(10000);
        	    	outstream.write(buffer, 0, length);
        	    	System.out.println("10 char printed....");
        	    	
        	        }
        	    	else
        	    	{
	        	    	outstream.write(buffer, 0, length);
	        	    	
	        	    	System.out.println("10 char printed....");
        	    	}

        	    //Closing the input/output file streams
        	    instream.close();
        	    outstream.close();

        	    System.out.println("File copied successfully!!");
     
        	}
        	}catch(IOException ioe ){
        		ioe.printStackTrace();
        	 }
        	catch(InterruptedException ioe ){
        		ioe.printStackTrace();
        	 }
        	catch(IllegalMonitorStateException ioe ){
        		ioe.printStackTrace();
        	 }
        	}
		
	}

	
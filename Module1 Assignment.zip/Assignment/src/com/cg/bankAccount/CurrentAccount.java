package com.cg.bankAccount;

public class CurrentAccount extends Account{
	double overDraftLimit=5000;
	@Override
	void withdraw(double amount) {
		super.withdraw(amount);
		if(amount>5000)
			System.out.println("Over Draft Limit is Reached.");
		else
			if(this.balance - amount>=500)
				this.balance -=amount;
			else
				System.out.println("Low balance");
	}
	
}

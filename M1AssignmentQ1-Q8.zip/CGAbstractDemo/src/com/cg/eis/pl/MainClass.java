package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeInsuranceSystem;

public class MainClass {
	public static void main(String[] aa) {
		Scanner scanner =  new Scanner(System.in);
		System.out.print("\nEnter your Id : ");
		int id = scanner.nextInt();
		scanner.nextLine();
		System.out.print("\nEnter your Name : ");
		String name = scanner.nextLine();
		System.out.print("\nEnter your Salary : ");
		int salary = scanner.nextInt();
		scanner.nextLine();
		System.out.print("\nEnter your designation : ");
		String designation = scanner.nextLine();
		EmployeeInsuranceSystem employeeInsuranceSystem = new EmployeeInsuranceSystem();
		String insuranceScheme = employeeInsuranceSystem.getScheme(salary, designation.trim());
		Employee emp = new Employee(id, salary, insuranceScheme, name, designation);
		System.out.println("Employee id : "+emp.getId());
		System.out.println("Employee Name : "+emp.getName());
		System.out.println("Employee Salary : "+emp.getSalary());
		System.out.println("Employee Designation : "+emp.getDesignation());
		System.out.println("Employee Insurance Scheme : "+emp.getInsuranceScheme());
	}
}

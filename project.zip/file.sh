#!/bin/bash
total_student_in_colege=`find $MMS_HOME/tanuj/project -name '*.txt' -print |wc -l`
echo "total in colege $total_student_in_colege"
cd project
for DIR in `ls`
do
	total_in_dept=`find $MMS_HOME/tanuj/project/$DIR -name '*.txt' -print |wc -l`
	echo "total in dept $DIR is $total_in_dept"
	cd $MMS_HOME/tanuj/project/$DIR
	filename=`ls |head -1`
	i=1
	while (( $i < `cat $filename|wc -l` )) || [ $i -eq `cat $filename| wc -l` ]
	do
		total_students=`ls -1 |wc -l`
		#subject=`head -n$i $filename |cut -d',' -f1`
		subject=`sed "${i}q;d" $filename |cut -d',' -f1`
		avg=`head -n$i *.txt | grep -v '==> ' |awk -F',' '{s+=$2}END{print s}' `
		avg_score=$(($avg/$total_students))
		echo "average of department $DIR in $subject is $avg_score" 
		echo "max_$subject$DIR.txt"
		head -n$i *.txt | grep -v '==> ' |awk -F',' '{print $2}' > ../../max_$subject$DIR.txt
		max=`sort -t= -nr -k3 max_$subject$DIR.txt |head -1`
		echo "max in dept $DIR in $subject is $max" 
		i=$((i+1))
	done
done
